let dato:any = "Nikola Tesla";
console.log ("El nombre es", dato);
dato = 1870;
console.log ("Nació en:", dato);



