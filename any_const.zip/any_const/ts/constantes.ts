const nombre:string = "Nikola Tesla";
console.log ("El nombre es:", nombre);

nombre = "John F. Kennedy";
console.log ("El nombre es:", nombre);
